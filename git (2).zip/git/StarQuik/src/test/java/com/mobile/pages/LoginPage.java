package com.mobile.pages;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

import org.apache.http.cookie.SM;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;


/**
 * Login Screen
 * 
 * @author Ankit Jain.
 *
 */
public class LoginPage extends BasePage {
	
	
	/**
	 * Allow permissions button.
	 */
	@FindBy(id="com.android.packageinstaller:id/permission_allow_button")
	private MobileElement allowPermissions;
	
	//------------------------------------------------------------------------------------------------------------------
	
	/**
	 * Auto Detect Location
	 */
	@FindBy(id="com.starquik:id/tv_new_user_detect")
	private MobileElement autoDetect;
	/**
	 * Set Location Manually
	 */
	@FindBy(id="com.starquik:id/tv_new_user_manual_select")
	private MobileElement ManualLocation;
	
	@FindBy(id="com.starquik:id/et_location_address")
	private MobileElement EnterLocation;
	
	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.support.v7.widget.RecyclerView/android.widget.LinearLayout[2]/android.widget.TextView")
	private MobileElement SelectLocation;
	
	
	@FindBy(id="com.starquik:id/tv_ls_confirm")
	private MobileElement ConfirmLocation;
	/**
	 * Open menu slider
	 */
	@FindBy(id="com.starquik:id/iv_home_navigation")
	private MobileElement Slider;
	
	
	@FindBy(id="com.starquik:id/tv_nav_name_item")
	private MobileElement Logon;
	
	@FindBy(id="com.starquik:id/email")
	private MobileElement userId;
	
	/**
	 * Password input text field.
	 */
	@FindBy(id="com.starquik:id/password")
	private MobileElement password;
	/**
	 * Button to be clicked for login.
	 */
	@FindBy(id="com.starquik:id/action_sign_in")
	private MobileElement loginButton;
	
	@FindBy(id="com.starquik:id/cl_wallet_balance")
	private MobileElement wallet;
	
	@FindBy(id="com.starquik:id/amount")
	private MobileElement walletAmount;
	
	@FindBy(id="com.starquik:id/btn_nav_smart_basket")
	private MobileElement SmartBasket;
	
	@FindBy(id="com.starquik:id/tv_toolbar_category")
	private MobileElement SmartBasketText;
	
	@FindBy(id="com.starquik:id/iv_home_search")
	private MobileElement search;
	
	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.support.v4.widget.DrawerLayout/android.widget.LinearLayout/android.widget.ScrollView/android.widget.LinearLayout/android.support.v7.widget.RecyclerView[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.ImageView")
	private MobileElement FirstAddButton;
	
	@FindBy(id="com.starquik:id/action_cart")
	private MobileElement CartButton;
	
/*	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.webkit.WebView/android.webkit.WebView/android.view.View[1]/android.view.View[2]/android.view.View[5]/android.view.View")
	private MobileElement logout;*/
	@FindBy(id="com.starquik:id/tv_cart_checkout")
	private MobileElement CheckoutButton;
	
	@FindBy(id="com.starquik:id/address_no")
	private MobileElement Address;
	
	@FindBy(id="com.starquik:id/edit_landmark")
	private MobileElement Landmark;
	
	@FindBy(id="com.starquik:id/action_done")
	private MobileElement savebutton;
	
	@FindBy(id="com.starquik:id/btn_delivery_payment")
	private MobileElement ProceedToPayment;
	
	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.support.v7.widget.LinearLayoutCompat/android.widget.HorizontalScrollView/android.widget.LinearLayout/android.support.v7.app.ActionBar.Tab[1]/android.widget.TextView")
	private MobileElement WalletOption;
	
	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.support.v7.widget.LinearLayoutCompat/android.widget.HorizontalScrollView/android.widget.LinearLayout/android.support.v7.app.ActionBar.Tab[2]/android.widget.TextView")
	private MobileElement CardOption;
	
	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.support.v7.widget.LinearLayoutCompat/android.widget.HorizontalScrollView/android.widget.LinearLayout/android.support.v7.app.ActionBar.Tab[3]")
	private MobileElement NetbankingOption;
	
	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.support.v7.widget.LinearLayoutCompat/android.widget.HorizontalScrollView/android.widget.LinearLayout/android.support.v7.app.ActionBar.Tab[4]")
	private MobileElement POD;
	@FindBy(id="com.starquik:id/btn_payment_submit")
	private MobileElement PaymentSubmit;
	
	@FindBy(id="com.starquik:id/iv_close_rate")
	private MobileElement CloseRating;
	
	@FindBy(id="com.starquik:id/btn_nav_my_orders")
	private MobileElement myOrders;
	
	@FindBy(id="com.starquik:id/address_no")
	private MobileElement houseNo;
	
	@FindBy(id="com.starquik:id/edit_landmark")
	private MobileElement landmark;
	
	@FindBy(id="com.starquik:id/edit_pin_code")
	private MobileElement PinCode;
	
	@FindBy(id="com.starquik:id/action_done")
	private MobileElement saveaddress;
	
	@FindBy(id="com.starquik:id/tv_nav_name_item")
	private MobileElement MyProfile;
	
	@FindBy(id="com.starquik:id/tv_nav_help_header")
	private MobileElement MyInfo;
	
	@FindBy(id="com.starquik:id/tv_add_a_new_address")
	private MobileElement AddNewAddressMyInfo;
	
	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.support.v7.widget.LinearLayoutCompat/android.widget.ScrollView/android.support.v7.widget.LinearLayoutCompat/android.support.v7.widget.RecyclerView/android.view.ViewGroup[1]/android.view.ViewGroup/android.widget.ImageView[2]")
	private MobileElement DeleteAddress;
	
	@FindBy(id="com.starquik:id/btn_sq_dialog_positive")
	private MobileElement ConfirmDeleteAddress;
	
	/**
	 * Constructor of the class.
	 * @param driver
	 */
	public LoginPage(AppiumDriver<WebElement> driver) {
		super(driver);
	}
	
	
	public void startTest(String testcaseName)
	{
		logger = extent.startTest(testcaseName);
	}

	/**
	 * Method to do login.
	 * @throws InterruptedException 
	 */
	public void doLogin(String p_user_id, String p_password, String Loc, String hno, String landmark, String PIN) throws InterruptedException {
		
		
		Thread.sleep(10000);
		Tap(ManualLocation, "Manual Location button");
		Longwait();
		Tap(EnterLocation, "Enter location textbox");
		Smallwait();
		Enterkeys(EnterLocation, "Location entered", Loc);
		Smallwait();
		Tap(SelectLocation, "Andheri Selected");
		Smallwait();
		Tap(ConfirmLocation, "Location Confirmed");
		Smallwait();
		Tap(Slider,"Menu Slider");
		Smallwait();
		Tap(Logon,"User Login");
		Smallwait();
		Enterkeys(userId,"user name",p_user_id);
		Smallwait();
		Enterkeys(password,"password",p_password);
		Smallwait();
		Tap(loginButton, "login button");
		Smallwait();
		Tap(wallet, "Wallet option");
		Smallwait();
		if(walletAmount.isDisplayed())
		{
		Report("Wallet is working", "PASS");
		} 
		else 
		{ 
		Report("User is not redirected to Wallet details", "FAIL");
		}
		takeScreenShot("Customer Wallet");
		Smallwait();
		clickBackButton();
		Smallwait();
		Tap(SmartBasket, "Smartbasket option");
		Smallwait();
		System.out.println(SmartBasketText.getText()+">>>>>>>>>>>>>>>>>>>>>>>>");
		takeScreenShot("Smart Basket");
		if (SmartBasketText.getText()=="Smart Basket") {
			Report("Smart Basket is working fine", "PASS");
		}
		else
			Report("User is not redirected to Smart Basket", "FAIL");
		Smallwait();
		clickBackButton();
		Smallwait();
		Tap(MyProfile, "My Profile option");
		Smallwait();
		Tap(MyInfo, "My info option");
		Smallwait();
		if (DeleteAddress.isDisplayed()) 
		{
			while(DeleteAddress.isDisplayed()) 
			{			
				Report("Address is available", "PASS");	
				Tap(DeleteAddress, "Delete Address button");
				Smallwait();
				Tap(ConfirmDeleteAddress, "Confirm delete address");
				Smallwait();
			}
	    }	
		else 
		{
			System.out.println(">>>>>>>>>>>>>>> Inside Else add address");
			Report("No address saved for this customer", "PASS");
			Smallwait();
			Tap(AddNewAddressMyInfo, "Add New Address button");
			Smallwait();
			Enterkeys(houseNo, "House Number", hno);
			Smallwait();
			Enterkeys(Landmark, "Landmark", landmark);
			Smallwait();
			if (PinCode.getText().isEmpty()) {
				Enterkeys(PinCode, "Pincode", PIN);
				scrollScreenDown();
			}
			else {
				scrollScreenDown();
			}
			Smallwait();
			Tap(saveaddress, "Save Address button");
			Smallwait();
			
		}
		}

	public MobileElement getUserId() {
		return userId;
	}
	public MobileElement getPassword() {
		return password;
	}
	public MobileElement getLoginButton() {
		return loginButton;
	}
	
	public void endTest()
	{
		extent.endTest(logger);
		extent.flush();
	}
	
}
