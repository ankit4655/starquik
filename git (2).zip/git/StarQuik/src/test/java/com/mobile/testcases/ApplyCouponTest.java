package com.mobile.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.mobile.pages.LoginPage;
import com.mobile.pages.ApplyCoupon;
import com.mobile.testdata.TestDataProvider;
import com.relevantcodes.extentreports.LogStatus;

import freemarker.log.Logger;



/**
 * Test class for Login.
 * 
 * @author Ankit Jain.
 *
 */
public class ApplyCouponTest extends BaseTestConfig {
	
	/**
	 * Variable of type {@link LoginPage}
	 */
	//private LoginPage page;
	private ApplyCoupon ApplyCoupon;
	//------------------------------------------------------------------------------------------------------------------
	@BeforeTest
	public void doBeforeTest() {
		//page = new LoginPage(driver);
		ApplyCoupon = new ApplyCoupon(driver);
	}

	//------------------------------------------------------------------------------------------------------------------
	@Test(dataProvider="placeOrderTestData", dataProviderClass=TestDataProvider.class)
	public void ACTest(String p_user_id, String p_password, String S_text, String loc, String address, String land, String Ccode) throws InterruptedException {
		ApplyCoupon.startTest("Apply Coupon Test");
		ApplyCoupon.doApplyCoupon(p_user_id, p_password, S_text, loc, address, land, Ccode);
	}
	//------------------------------------------------------------------------------------------------------
	@AfterTest
	public void doAfterTest() {	
		
		ApplyCoupon.endTest();
       // extent.close();
	}
	//------------------------------------------------------------------------------------------------------------------

}
